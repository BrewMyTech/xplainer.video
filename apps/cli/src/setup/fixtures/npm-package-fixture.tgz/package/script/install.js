console.error("this postinstall must never run");
